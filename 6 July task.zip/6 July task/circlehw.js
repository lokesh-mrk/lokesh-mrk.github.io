function find(){
	var num1 = document.getElementById('t1').value;
	var area = 3.14*num1*num1;
	var perimeter = 2*3.14*num1;
	document.getElementById('t2').value = area;
	document.getElementById('t3').value = perimeter;
	
	
}